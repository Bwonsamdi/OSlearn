git add .
git commit -a -m "lab1 modified"

